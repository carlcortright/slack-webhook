################################################################################
# Python package __init__.py file.
#
# Author: Carl Cortright
# Date: 12/20/2016
#
################################################################################

from slackwebhook import slackwebhook
